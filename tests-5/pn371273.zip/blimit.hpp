#pragma once

unsigned int bvalue(unsigned int method, unsigned long node_id); 
